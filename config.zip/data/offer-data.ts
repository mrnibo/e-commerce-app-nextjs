export const offerData ={
    text: "Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%",
    btnText: "Shop Now",
    btnHref: "/swim-suits"
}