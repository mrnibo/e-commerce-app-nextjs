export const navbarData = {
    links: [
        {
            name: "Home",
            href: "/",
        },
        {
            name: "Contact",
            href: "/contact",
        },
        {
            name: "About",
            href: "/about",
        },

        {
            name: "Shop",
            href: "/shop",
        },
    ]
}