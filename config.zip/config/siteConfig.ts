
export const siteConfig = {
    title: "Next.js",
    description: "The React Framework for Production",
    logo: "Exclusive",
   favIco: "/favicon.ico",
    links: {
        facebook: "https://facebook.com/withnextjs",
        instagram: "https://instagram.com/withnextjs",
        twitter: "https://twitter.com/withnextjs",
        linkedin: "https://linkedin.com/withnextjs",
    },

}
;