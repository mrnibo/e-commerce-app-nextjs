import React from "react";

const Footer = () => {
  return (
    <>
      <div className="bg-black text-white p-4 flex justify-center items-center">
        Copyright Rimel 2022. All right reserved{" "}
      </div>
    </>
  );
};

export default Footer;
